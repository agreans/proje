
<br>
<br>

<div class="_nuxt_footer mb25 gap20">
    
<a href="/" class="_nuxt_header_logo footer">
 <span class="_nuxt_header_logo_title">LOTBET</span>
 <span class="_nuxt_header_logo_description">Онлайн игры</span>
</a>
<hr>
<span class="_nuxt_footer_info_site">© 2024 <span class="_nuxt_lower">www.<?=$sitename?>.<?=$sitedomen?></span> | Все права защищены.</span>

<div class="_nuxt_footer_contacts">
<span class="_nuxt_footer_contact"> Помощь <a>support@<?=$sitename?>.<?=$sitedomen?></a> </span>
<span class="_nuxt_footer_contact"> Партнеры <a>partners@<?=$sitename?>.<?=$sitedomen?></a> </span>
<span class="_nuxt_footer_contact"> Пресса <a>press@<?=$sitename?>.<?=$sitedomen?></a> </span>
</div>

<div class="_nuxt_footer_contacts" style="    justify-content: center;">
<span class="_nuxt_footer_contact"><a style="text-transform: math-auto;opacity: 0.3;" href="/terms">Пользовательское соглашение</a> </span>
<span class="_nuxt_footer_contact"><a style="text-transform: math-auto;opacity: 0.3;" href="/policy">Политика конфиденциальности</a> </span>
</div>


<div class="_nuxt_footer_alert">
<span class="_nuxt_footer_alert_18">18+</span>

<div class="_nuxt_footer_alert_box">
<span>Сервис является развлекательным и предназначен для лиц старше 18 лет!</span>    
<span>Не является азартной игрой.</span>    
</div>

</div>

</div>

<br>
<br>

