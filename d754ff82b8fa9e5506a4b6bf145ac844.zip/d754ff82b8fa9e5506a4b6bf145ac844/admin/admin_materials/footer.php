<style>
.footer{
    display: flex;
    justify-content: space-between;
    margin-top: 20px;    
    font-size: 14px;    
}    
</style>

<div class="footer">
 <span>© 2024 <?=$sitename?> - Все права защищены и охраняются законом.</span>
 <span>Разработка скриптов <a href="https://cheezystore.ru">cheezystore.ru</a></span> 
</div>